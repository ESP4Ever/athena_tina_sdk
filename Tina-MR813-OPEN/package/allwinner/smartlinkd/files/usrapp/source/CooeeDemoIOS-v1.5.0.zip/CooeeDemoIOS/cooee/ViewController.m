//
//  ViewController.m
//  cooee
//
//  Created by apk on 2014/11/14.
//  Copyright (c) 2014年 cooee. All rights reserved.
//

#import "ViewController.h"
#import <stdio.h>
#import "cooee.h"
#import "Reachability.h"
#import <SystemConfiguration/CaptiveNetwork.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
@interface ViewController ()
{
    BOOL Send;
    NSString *wifiName;
    const char *PWD;
    const char *SSID;
    const char *KEY;
    unsigned int ip;
    NSTimer *Send_cooee;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(disappearSelector) name:UIApplicationWillResignActiveNotification object:nil];
    
    _send_btn.layer.borderWidth = 1;
    _send_btn.layer.borderColor = [[UIColor grayColor] CGColor];
    _send_btn.layer.cornerRadius = 10.5;
    _ssid.adjustsFontSizeToFitWidth = YES;
    _pwd.adjustsFontSizeToFitWidth = YES;
    if ([[Reachability reachabilityForLocalWiFi] currentReachabilityStatus] != NotReachable) {
        NSLog(@"Wifi connect");
        

        Send = false;
        [_send_btn setTitle:@"Start" forState:UIControlStateNormal];
        NSArray *ifs = (__bridge id)CNCopySupportedInterfaces();
        id info = nil;
                for (NSString *ifnam in ifs) {
            info = (__bridge id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
            if(info && [info count]){
                NSDictionary *dic = (NSDictionary*)info; //取得網卡的資訊
                wifiName = [dic objectForKey:@"SSID"];   //取得ssid
                break;
            }
        }
        _ssid.text = wifiName;
        
    }else{
        NSLog(@"No Wifi");
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Wi-Fi not connected , abort"
                              message:nil
                              delegate:self
                              cancelButtonTitle:NSLocalizedString(@"OK", nil)
                              otherButtonTitles:nil, nil];
        [alert show] ;

    }
}

- (void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    switch (buttonIndex) {
        case 0: {
            exit(0);
            break;
        }
        
        default:
            break;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)disappearSelector{
    NSLog(@"disappearSelector");
    
    if(Send){
        [self.send_btn setTitle:@"Start" forState:UIControlStateNormal];
    
        dispatch_async(dispatch_get_main_queue(), ^(void){
        [self.send_btn setTitle:@"Start" forState:UIControlStateNormal];
        });
        Send = !Send;
    }
    
}

- (IBAction)send_btn:(id)sender {
    
        Send = !Send;
    
        if (Send) {
         
            [sender setTitle:@"Stop" forState:UIControlStateNormal];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                while (Send) {
                    
                    PWD = [[_pwd text] UTF8String];
                    SSID = [[_ssid text] UTF8String];
                    
                    KEY = [@"" UTF8String];
                    struct in_addr addr;
                    inet_aton([[self getIPAddress] UTF8String], &addr);
                    ip = CFSwapInt32BigToHost(ntohl(addr.s_addr));
                    
                    /*
                    NSLog(@"StartCooee");
                    NSLog(@"SSID = %s , len = %lu " , SSID , strlen(SSID));
                    NSLog(@"PWD = %s , len = %lu ", PWD , strlen(PWD));
                    NSLog(@"[self getIPAddress] = %@" , [self getIPAddress]);
                    NSLog(@"ip = %08x", ip);
                    */

                    send_cooee(SSID, (int)strlen(SSID), PWD, (int)strlen(PWD), KEY, 0, ip);
                }
            });
        }else{
            [sender setTitle:@"Start" forState:UIControlStateNormal];
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
               [sender setTitle:@"Start" forState:UIControlStateNormal];
            });
        }
    
        /*if (Send) {
            [sender setTitle:@"Stop" forState:UIControlStateNormal];
            Send_cooee = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(StartCooee) userInfo:nil repeats:YES];
        }else{
            [sender setTitle:@"Start" forState:UIControlStateNormal];
            if ([Send_cooee isValid]) {
                [Send_cooee invalidate];
                Send_cooee = nil;
            }
        
        }*/
    
}

-(void)StartCooee{
    NSLog(@"StartCooee");
    PWD = [[_pwd text] UTF8String];
    SSID = [[_ssid text] UTF8String];
    
    KEY = [@"" UTF8String];
    struct in_addr addr;
    inet_aton([[self getIPAddress] UTF8String], &addr);
    ip = CFSwapInt32BigToHost(ntohl(addr.s_addr));
    
    NSLog(@"SSID = %s" , SSID);
    NSLog(@"strlen(SSID) = %lu" , strlen(SSID));
    NSLog(@"PWD = %s" , PWD);
    NSLog(@"strlen(PWD) = %lu" , strlen(PWD));
    
    NSLog(@"[self getIPAddress] = %@" , [self getIPAddress]);
    NSLog(@"ip = %08x", ip);
    send_cooee(SSID, (int)strlen(SSID), PWD, (int)strlen(PWD), KEY, 0, ip);
}

- (NSString *)getIPAddress
{
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0)
    {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL)
        {
            if(temp_addr->ifa_addr->sa_family == AF_INET)
            {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"])
                {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    
    // Free memory
    freeifaddrs(interfaces);
    
    return address;
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    NSLog(@"viewDidDisappear");
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSLog(@"viewWillDisappear");
}

- (void)applicationFinishedRestoringState{
    
    NSLog(@"applicationFinishedRestoringState");
}

- (void)willMoveToParentViewController:(UIViewController *)parent{
    NSLog(@"willMoveToParentViewController");
}

@end
