//
//  ViewController.h
//  cooee
//
//  Created by apk on 2014/11/14.
//  Copyright (c) 2014年 cooee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "cooee.h"
#import "Reachability.h"
@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *ssid;
@property (strong, nonatomic) IBOutlet UITextField *pwd;
@property (strong, nonatomic) IBOutlet UIButton *send_btn;


@end

