package com.aw;
public class SoundAuthentication{
	
	private final String TAG = "llh>>>SoundAuthentication";

	static {  
        System.loadLibrary("SoundAutentication_jni");   
    }
	
	/*设置是否打开jni层的调试信息，如果enableFlag为true，则打开jni层的调试信息，否则不打开
	注：打开该调试信息，会在/mnt/sdcard/目录保存编码或解码后的pcm数据，所以一般正常使用的时候应该关闭该调试信息
	*/
	public native void setDebugFlag(boolean enableFlag);
	
	/*
	设置编解码器的参数，其中:
	max_str_len:最大能够编码或解码的字符数目，该值一般设为128
	sample_rate:采样率,单位为HZ，该值一般设为44100
	freq_type:频率类型，有低频、中频、高频3种，其中低频、中频、高频分别对应的值为0、1、2
	error_correct:是否采用纠错码，其中0表示不采用纠错码，1表示采用纠错码。该值一般设为1
	error_correct_num:纠错码的纠错能力(字节数)，该值一般设为4
	group_symbol_num:每个分组传输的字节数，该值一般设为10
	*/
	public native void setEnDecoderParameters(int max_str_len,int sample_rate,int freq_type,int error_correct,int error_correct_num,int group_symbol_num);
	
	/*把输入的字符串编码成pcm数据返回，参数：input_str表示需要编码的字符串，返回值：表示输入的字符串input_str编码后返回的pcm数据。如果编码失败，则返回null*/
	public native short[] nativeEncodeStrToPcm(String input_str);
	
	/*创建解码器，返回值为底层每次输入到解码器中的pcm数据的长度。如果返回值为0，则表示解码器创建失败*/
	public native int nativeCreatDecoder();
	
	/*销毁解码器*/
	public native void nativeDestroyDecoder();
	
	/*把输入的pcm数据解码出对应的字符串返回，参数：input_pcm表示每次需要解码的pcm数据，返回值：输入的pcm数据解码后的字符串。
	 * 如果返回值为null，则表示输入的pcm数据还不足以解出字符串，需要继续输入pcm数据。如果解码出错，会返回字符串："decode_error" */
	public native String nativeDecodePcmToStr(short[] input_pcm);
	
}