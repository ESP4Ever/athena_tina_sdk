package com.aw.soundauthenticationtest;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import com.aw.SoundAuthentication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.app.Activity;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private final String TAG = "llh>>>MainActivity";
	private AudioTrack mAudioTrack;
	private SoundAuthentication mSoundAuthentication;
	private EditText mInputSsidEditText;
	private EditText mInputPasswordEditText;
	private Button mStartBt;
	private File mSaveTransferedPcmFile;
	private DataOutputStream mDataOutputStream;
	private final int ENABLE_START_BUTTON_MSG = 0;
	private final int DISABLE_START_BUTTON_MSG = 1;
	
	private int mMaxStrLen = 128;
	private int mSampleRate = 16000;
	private int mFreqType = 0;//0 is low freq,1 is middle freq,2 is high freq
	private int mErrorCorrect = 1;
	private int mErrorCorrectNum = 4;
	private int mGroupSymbolNum = 10;

	private RadioGroup freqTypeChoose;
	private EditText etSampleRate;

	int offset;

	private Uri urlPcmFile = null;

	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ENABLE_START_BUTTON_MSG:
				mStartBt.setEnabled(true);
				break;
			case DISABLE_START_BUTTON_MSG:
				mStartBt.setEnabled(false);
				break;
			default:
				break;
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		Log.d(TAG, "onCreate");
		mSoundAuthentication = new SoundAuthentication();
		mInputSsidEditText = (EditText)findViewById(R.id.ssid_editText_id);
		mInputPasswordEditText = (EditText)findViewById(R.id.password_editText_id);
		mStartBt = (Button)findViewById(R.id.start_bt_id);
		freqTypeChoose = (RadioGroup)findViewById(R.id.freq_type_choose);
		etSampleRate =(EditText) findViewById(R.id.etSampleRate);
		mStartBt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Log.d(TAG, "mStartBt is clicked");
				if(mInputPasswordEditText.getText().toString().length() < 8){
					Toast toast = Toast.makeText(MainActivity.this, "the password length is less than 8,please input more data", Toast.LENGTH_LONG);
					toast.setGravity(Gravity.TOP, 50, 220);
					toast.show();
				}else{
					mStartBt.setEnabled(false);
//					creatTransferFile();
					new Thread(){
						public void run() {
							String tmpInputSsidStr = mInputSsidEditText.getText().toString();
							String tmpInputPasswordStr = mInputPasswordEditText.getText().toString();
							String inputSsidStr = null;
							String inputPasswordStr = null;
							try {
								switch(freqTypeChoose.getCheckedRadioButtonId()){
									case R.id.low_Rate:
										mFreqType=0;
										break;
									case R.id.middle_Rate:
										mFreqType=1;
										break;
									case R.id.high_Rate:
										mFreqType=2;
										break;
								}
								byte[] tmpSsidByte = tmpInputSsidStr.getBytes();
								byte[] tmpPasswordByte = tmpInputPasswordStr.getBytes();

								inputSsidStr = new String(tmpSsidByte, "utf-8");
								inputPasswordStr = new String(tmpPasswordByte, "utf-8");

							} catch (UnsupportedEncodingException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							String allWifiStr = null;
							if(inputSsidStr.equals("")){//没有手动输入wifi名称，所以直接使用已连接的那个wifi名称
								Log.d(TAG, "do not input ssid");
								//把wifi的ssid和password组成一个字符串,用"::div::"这个字符串把他们分隔开，接收端也要根据这个分隔字符串取出相应的ssid和password
								allWifiStr = getSSIDname()+"::div::"+inputPasswordStr;
							}else{//手动输入了wifi名称，所以用手动输入的那个wifi名称
								Log.d(TAG, "manual input ssid:"+inputSsidStr);
								//把wifi的ssid和password组成一个字符串,用"::div::"这个字符串把他们分隔开，接收端也要根据这个分隔字符串取出相应的ssid和password
								allWifiStr = inputSsidStr+"::div::"+inputPasswordStr;
							}
							mSoundAuthentication.setDebugFlag(true);
							mSampleRate = Integer.parseInt(etSampleRate.getText().toString());
							mSoundAuthentication.setEnDecoderParameters(mMaxStrLen,mSampleRate,mFreqType,mErrorCorrect,mErrorCorrectNum,mGroupSymbolNum);
							short[] pcm_data = mSoundAuthentication.nativeEncodeStrToPcm(allWifiStr);//把需要编码的字符串(allWifiStr)传给编码器
							if(pcm_data == null){//编码失败
								Log.e(TAG, "encode error");
							}else{//编码成功，返回值为该字符串编码后的pcm数据								
								Log.d(TAG, "pcm_data len = "+pcm_data.length);
//								savePcmDataInFile(pcm_data);
								playPcm(pcm_data);//把编码后的pcm数据拿去播放
								stopPcm();//停止播放
//								closeFile();
							}
							mHandler.sendEmptyMessage(ENABLE_START_BUTTON_MSG);
						};
					}.start();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/*注：以下两个参数不能改变：采样精度为 16bit , 采样通道为:单声道(mono)。采样率需要和接收端的采样率一致，一般设为44100*/
	private void playPcm(short[] pcmData){
		int index = 0;
		int minBufSizeInByte = AudioTrack.getMinBufferSize(mSampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
		Log.d("llh>>>", "minBufSizeInByte = "+minBufSizeInByte);
		if(mAudioTrack == null){
			mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, mSampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, minBufSizeInByte, AudioTrack.MODE_STREAM);
		}
		int minBufSizeInShrot = minBufSizeInByte/2;
		mAudioTrack.play();
		while((index*minBufSizeInShrot) < pcmData.length){
			if((pcmData.length - index*minBufSizeInShrot)>=minBufSizeInShrot){
				mAudioTrack.write(pcmData, index*minBufSizeInShrot, minBufSizeInShrot);
			}else{
				mAudioTrack.write(pcmData, index*minBufSizeInShrot, pcmData.length - index*minBufSizeInShrot);
			}
			index++;
		}
		
	}
	
	private void stopPcm(){
		if(mAudioTrack != null){
			mAudioTrack.flush();
			mAudioTrack.stop();
			mAudioTrack = null;
		}
	}
	
	private String getSSIDname(){
		String ssidName = null;
		WifiManager wifiManager = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
		WifiInfo wifiInfo = wifiManager.getConnectionInfo();
		String tempSsidName = wifiInfo.getSSID().substring(1, wifiInfo.getSSID().length()-1);
		try {
			ssidName = new String(tempSsidName.getBytes(), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		Log.d(TAG, "ssid name = "+ssidName);
		Log.d(TAG, "ssid name len = "+ssidName.length());
		Log.d(TAG, "bssid name = "+wifiInfo.getBSSID());
		Log.d(TAG, "wifi info = "+wifiInfo.toString());
		return ssidName;
	}
}
